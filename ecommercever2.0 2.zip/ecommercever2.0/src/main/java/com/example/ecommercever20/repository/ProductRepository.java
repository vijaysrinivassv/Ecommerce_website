package com.example.ecommercever20.repository;

import com.example.ecommercever20.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    // Find products by brand
    List<Product> findByBrand(String brand);

    // Find accessories by brand and category
    List<Product> findByBrandAndCategory(String brand, String category);

    // Find products by category (used for recommendations and accessory fetching)
    List<Product> findByCategory(String category);

    List<Product> findByAddToCart(String addtocart, String add);









}



