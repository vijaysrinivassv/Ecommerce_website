package com.example.ecommercever20.controller;

import com.example.ecommercever20.model.Product;
import com.example.ecommercever20.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ProductController {

    @Autowired
    private ProductService productService;



    @GetMapping("/products")
    public String showProductList(Model model) {
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
        return "product-list";
    }

    @GetMapping("/products/{id}")
    public String getProductById(@PathVariable Long id, Model model) {
        Product product = productService.getProductById(id).orElse(null);
        List<Product> recommendations = productService.getRecommendations(id);

        model.addAttribute("product", product);
        model.addAttribute("recommendations", recommendations);
        return "product-details";  // Render the product-details.html template
    }

    @GetMapping("/products/brand/{brand}")
    public String getProductsByBrand(@PathVariable String brand, Model model) {
        List<Product> products = productService.getProductsByBrand(brand);
        model.addAttribute("products", products);
        model.addAttribute("brand", brand);
        return "product-list";  // Reuse product-list.html template
    }

    // Display accessories by brand
    @GetMapping("/products/brand/{brand}/accessories")
    public String getAccessoriesByBrand(@PathVariable String brand, Model model) {
        List<Product> accessories = productService.getAccessoriesForProduct(brand);
        model.addAttribute("products", accessories);
        model.addAttribute("brand", brand);
        model.addAttribute("category", "accessories");
        return "product-list";  // Reuse product-list.html template
    }
    @GetMapping("/brands/apple")
    public String getAppleProducts(Model model) {
        List<Product> products = productService.getProductsByBrand("Apple"); // Fetch only Apple products
        model.addAttribute("products", products);
        model.addAttribute("brand", "Apple");
        return "apple-products";  // Return apple-products.html template
    }
    @GetMapping("/brands/samsung")
    public String getSamsungProducts(Model model) {
        List<Product> products = productService.getProductsByBrand("Samsung");
        model.addAttribute("products", products);
        model.addAttribute("brand", "Samsung");
        return "samsung-products";
    }
    @GetMapping("/brands/google")
    public String getGoogleProducts(Model model) {
        List<Product> products = productService.getProductsByBrand("Google"); // Fetch only Apple products
        model.addAttribute("products", products);
        model.addAttribute("brand", "Google");
        return "google-products";
    }
    @GetMapping("/accessories")
    public String getOthersProducts(Model model) {
        List<Product> products = productService.getProductsByBrand("Others");
        model.addAttribute("products", products);
        model.addAttribute("brand", "Others");
        return "accessories";
    }


    @GetMapping("/about-us")
    public String showAboutUsPage() {
        return "about-us";
    }
    @GetMapping("/addtocart")
    public String showAddToCart(Model model) {
        List<Product> products = productService.getAddtocart("add");
        model.addAttribute("products", products);
        model.addAttribute("addtocart","add");
        return "addtocart";
    }


}
