package com.example.ecommercever20.service;

import com.example.ecommercever20.model.Product;
import com.example.ecommercever20.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // Get a product by its ID
    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    // Get products by brand
    public List<Product> getProductsByBrand(String brand) {
        return productRepository.findByBrand(brand);
    }

    public List<Product> getAccessoriesForProduct(String brand) {
        return productRepository.findByBrandAndCategory(brand, "accessory");
    }

    public List<Product> getRecommendations(Long productId) {
        Optional<Product> product = productRepository.findById(productId);
        if (product.isPresent()) {
            String category = product.get().getCategory();
            return productRepository.findByCategory(category);
        }
        return List.of();
    }

    public List<Product> getAddtocart(String addtocart)
    {
        return productRepository.findByAddToCart(addtocart,"add");
    }

}
