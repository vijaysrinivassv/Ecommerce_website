package com.example.ecommercever20.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String brand;
    private String name;
    private String description;
    private String price;
    private String image;
    private String category;
    private String image1;
    private String images2;
    private String images3;
    private String description1;
    private String description2;
    private String description3;
    private String addtocart;



    public Product() {
    }



    public Product(String brand, String category, String description, Long id, String image, String name, String price,String image1,String images2,String images3,String description1 ,String description2,String description3,String addtocart) {
        this.brand = brand;
        this.category = category;
        this.description = description;
        this.image = image;
        this.name = name;
        this.price = price;
        this.image1=image1;
        this.images2=images2;
        this.images3=images3;
        this.description1=description1;
        this.description2=description2;
        this.description3=description3;
        this.addtocart=addtocart;



    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getImage1() {
        return image1;
    }

    public void setImage1(String image1) {
        this.image1 = image1;
    }

    public String getImages2() {
        return images2;
    }

    public void setImages2(String images2) {
        this.images2 = images2;
    }

    public String getImages3() {
        return images3;
    }

    public void setImages3(String images3) {
        this.images3 = images3;
    }

    public String getDescription1() {
        return description1;
    }

    public void setDescription1(String description1) {
        this.description1 = description1;
    }

    public String getDescription2() {
        return description2;
    }

    public void setDescription2(String description2) {
        this.description2 = description2;
    }

    public String getDescription3() {
        return description3;
    }

    public void setDescription3(String description3) {
        this.description3 = description3;
    }

    public String getAddtocart() {
        return addtocart;
    }

    public void setAddtocart(String addtocart) {
        this.addtocart = addtocart;
    }
}
