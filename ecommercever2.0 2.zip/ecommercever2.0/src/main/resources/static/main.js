document.addEventListener('DOMContentLoaded', () => {
  const products = [
    {
      name: "Google Pixel 6",
      images: [
        <img th:src="${product.image}" alt="Product image" width="600" height="400" />
        <img th:src="${product.image1}" alt="Product image1" width="600" height="400" />
        <img th:src="${product.images2}" alt="Product images2" width="600" height="400" />
        <img th:src="${product.images3}" alt="Product images3"  width="600" height="400"/>
      ],
      description: "The latest Google Pixel smartphone with advanced camera features.",
      price: 599.99
    },
  ];

  const productList = document.getElementById('productList');

  products.forEach((product, index) => {
    const productHTML = `
      <div class="col-md-6 mb-4">
        <div class="card">
          <div id="carousel${index}" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              ${product.images.map((img, i) => `
                <div class="carousel-item ${i === 0 ? 'active' : ''}">
                  <img src="${img}" class="d-block w-100" alt="${product.name} image ${i + 1}">
                </div>
              `).join('')}
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carousel${index}" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carousel${index}" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
          <div class="card-body">
            <h5 class="card-title">${product.name}</h5>
            <p class="card-text">${product.description}</p>
            <p class="card-text"><strong>Price: $${product.price.toFixed(2)}</strong></p>
          </div>
        </div>
      </div>
    `;
    productList.innerHTML += productHTML;
  });
});